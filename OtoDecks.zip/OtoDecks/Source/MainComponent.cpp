#include "MainComponent.h"

//==============================================================================
MainComponent::MainComponent()
{
    // Make sure you set the size of the component after
    // you add any child components.
    setSize (800, 600);

    // Some platforms require permissions to open input channels so request that here
    if (juce::RuntimePermissions::isRequired (juce::RuntimePermissions::recordAudio)
        && ! juce::RuntimePermissions::isGranted (juce::RuntimePermissions::recordAudio))
    {
        juce::RuntimePermissions::request (juce::RuntimePermissions::recordAudio,
                                           [&] (bool granted) { setAudioChannels (granted ? 2 : 0, 2); });
    }
    else
    {
        // Specify the number of input and output channels that we want to open
        setAudioChannels (0, 2);
    }
    
    addAndMakeVisible(deckGUI1);
    addAndMakeVisible(deckGUI2);
    
    addAndMakeVisible(playlistComponent);
    
    formatManager.registerBasicFormats();
    
}

MainComponent::~MainComponent()
{
    // This shuts down the audio device and clears the audio source.
    shutdownAudio();
}

//==============================================================================
void MainComponent::prepareToPlay (int samplesPerBlockExpected, double sampleRate)
{
    
    player1.prepareToPlay(samplesPerBlockExpected, sampleRate);
    player2.prepareToPlay(samplesPerBlockExpected, sampleRate);
    
    //mixerSource.prepareToPlay(samplesPerBlockExpected, sampleRate);

    mixerSource.addInputSource(&player1, false);
    mixerSource.addInputSource(&player2, false);
    
//    formatManager.registerBasicFormats();
//    transportSource.prepareToPlay(samplesPerBlockExpected, sampleRate);
//
//    resampleSource.prepareToPlay(samplesPerBlockExpected, sampleRate);

}

void MainComponent::getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill)
{
    //transportSource.getNextAudioBlock(bufferToFill);
    //resampleSource.getNextAudioBlock(bufferToFill);
    
    //player1.getNextAudioBlock(bufferToFill);
    
    mixerSource.getNextAudioBlock(bufferToFill);
    
}


//void MainComponent::getNextAudioBlock (const juce::AudioSourceChannelInfo& bufferToFill)
//{
//    auto* leftChan = bufferToFill.buffer->getWritePointer(0, bufferToFill.startSample);
//    auto* rightChan = bufferToFill.buffer->getWritePointer(0, bufferToFill.startSample);
//
//
//    for (auto i=0; i<bufferToFill.numSamples; ++i) {
//
//        //double sample = rand.nextDouble() * 0.25;
//        //double sample = fmod(phase, 0.2);
//        double sample = sin(phase) * 0.1;
//
//        leftChan[i] = sample;
//        rightChan[i] = sample;
//
//        phase += dphase;
//
//    }
//
//    //bufferToFill.clearActiveBufferRegion();
//}

void MainComponent::releaseResources()
{
    // This will be called when the audio device stops, or when it is being
    // restarted due to a setting change.

    // For more details, see the help for AudioProcessor::releaseResources()
    //transportSource.releaseResources();
    
    player1.releaseResources();
    player2.releaseResources();
    mixerSource.releaseResources();
}

//==============================================================================
void MainComponent::paint (juce::Graphics& g)
{
    // (Our component is opaque, so we must completely fill the background with a solid colour)
    g.fillAll (getLookAndFeel().findColour (juce::ResizableWindow::backgroundColourId));

    // You can add your drawing code here!
}

void MainComponent::resized()
{
 
    deckGUI1.setBounds(0, 0, getWidth()/2, getHeight()/2);
    deckGUI2.setBounds(getWidth()/2, 0, getWidth()/2, getHeight()/2);
    
    playlistComponent.setBounds(0, getHeight()/2, getWidth(), getHeight()/2);


}

void MainComponent::buttonClicked(juce::Button* button)
{
//    if (button == &playButton) {
//        std::cout << " Play Button was clicked " << std::endl;
//        player1.start();
//
//        //transportSource.start();
//
//    }
//    if (button == &stopButton) {
//        std::cout << " Stop Button was clicked " << std::endl;
//        player1.stop();
//
//        //transportSource.stop();
//    }
//    if (button == &loadButton) {
//        juce::FileChooser chooser{"Select a file..."};
//        if (chooser.browseForFileToOpen()) {
//            player1.loadURL(juce::URL{chooser.getResult()});
//
//            //loadURL(juce::URL{chooser.getResult()});
//        }
//    }
    
}

void MainComponent::sliderValueChanged (juce::Slider *slider)
{
//    if (slider == &volSlider) {
//        //std::cout << "vol slider moved " << slider->getValue() << std::endl;
//        //dphase = volSlider.getValue() * 0.01;
//      //  transportSource.setGain(slider->getValue());
//        
//        player1.setGain(slider->getValue());
//        
//    }
//    
//    if (slider == &speedSlider) {
//        
//        //resampleSource.setResamplingRatio(slider->getValue());
//        player1.setSpeed(slider->getValue());
//        
//    }
//    
//    if (slider == &posSlider)
//        {
//            player1.setPositionRelative(slider->getValue());
//        }
    
}

